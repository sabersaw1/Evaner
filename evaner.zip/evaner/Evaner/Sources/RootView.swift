import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            DashboardView().tabItem { Label("Dashboard", systemImage: "sparkles") }
            EventsView().tabItem { Label("Events", systemImage: "calendar") }
            GroupCardView().tabItem { Label("Card", systemImage: "creditcard") }
            MapView().tabItem { Label("Map", systemImage: "map") }
            ProfileView().tabItem { Label("Profile", systemImage: "person") }
        }
        .accentColor(AppTheme.electricBlue)
    }
}
