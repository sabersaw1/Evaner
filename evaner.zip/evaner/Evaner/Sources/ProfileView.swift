import SwiftUI

struct ProfileView: View {
    var body: some View {
        ZStack { AppTheme.midnight.edgesIgnoringSafeArea(.all)
            VStack { Text("Profile").foregroundColor(AppTheme.electricBlue); Spacer() }.padding()
        }
    }
}
