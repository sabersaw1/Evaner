import SwiftUI

struct GroupCardView: View {
    @EnvironmentObject var approvals: ApprovalStore
    @State private var amount = ""
    var body: some View {
        ZStack { AppTheme.midnight.edgesIgnoringSafeArea(.all)
            VStack {
                Text("Shared Card").foregroundColor(AppTheme.electricBlue)
                TextField("Amount", text: $amount).padding().background(Color.white.opacity(0.06)).cornerRadius(8)
                Spacer()
            }.padding()
        }
    }
}
