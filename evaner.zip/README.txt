Cleaned EventBuddy project prepared for CodeMagic build.
