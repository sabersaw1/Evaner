import SwiftUI

struct EventsView: View {
    var body: some View {
        ZStack { AppTheme.midnight.edgesIgnoringSafeArea(.all)
            VStack { Text("Events").foregroundColor(.white); Spacer() }.padding()
        }
    }
}
