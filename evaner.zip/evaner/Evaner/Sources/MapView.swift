import SwiftUI

struct MapView: View {
    var body: some View {
        ZStack { AppTheme.midnight.edgesIgnoringSafeArea(.all)
            VStack { Text("Map").foregroundColor(AppTheme.electricBlue); Spacer() }.padding()
        }
    }
}
