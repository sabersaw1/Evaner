import SwiftUI

struct DashboardView: View {
    var body: some View {
        ZStack {
            AppTheme.midnight.edgesIgnoringSafeArea(.all)
            VStack {
                Text("EventBuddy").font(.largeTitle).foregroundColor(AppTheme.electricBlue)
                Spacer()
            }.padding()
        }
    }
}
