import Foundation
import Combine

class ApprovalRequest: Identifiable, Codable {
    var id = UUID().uuidString
    var merchant: String
    var amount: Double
    var requestedBy: String
    var approvals: [String:Bool] = [:]
    var status: String = "pending"
    init(merchant:String, amount:Double, requestedBy:String, members:[String]) {
        self.merchant = merchant; self.amount = amount; self.requestedBy = requestedBy
        for m in members { approvals[m] = false }
    }
}

class ApprovalStore: ObservableObject {
    @Published var requests: [ApprovalRequest] = []
    var members = ["Member1","Member2","Member3","Member4"]
    func createRequest(merchant:String, amount:Double, requestedBy:String) {
        let r = ApprovalRequest(merchant:merchant, amount:amount, requestedBy:requestedBy, members: members)
        requests.append(r)
    }
    func approve(requestId:String, member:String) {
        guard let idx = requests.firstIndex(where: { $0.id == requestId }) else { return }
        requests[idx].approvals[member] = true
        if !requests[idx].approvals.values.contains(false) { requests[idx].status = "approved" }
    }
}
