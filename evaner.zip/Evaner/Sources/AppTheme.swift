import SwiftUI
struct AppTheme {
    static let electricBlue = Color(red: 0.0, green: 0.66, blue: 1.0)
    static let neonPurple = Color(red: 0.6, green: 0.2, blue: 1.0)
    static let midnight = Color(red: 0.04, green: 0.04, blue: 0.08)
}
