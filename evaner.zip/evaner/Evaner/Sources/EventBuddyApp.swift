import SwiftUI

@main
struct EventBuddyApp: App {
    @StateObject var approvals = ApprovalStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(approvals)
        }
    }
}
